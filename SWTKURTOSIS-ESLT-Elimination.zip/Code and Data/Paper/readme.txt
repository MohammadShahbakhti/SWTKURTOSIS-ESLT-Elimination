If you found this paper useful, please cite as

@article{Shahbakhti2020SWT-kurtosis,
  title={SWT-kurtosis Based Algorithm for Elimination of Electrical Shift and Linear Trend from EEG
Signals},
  author={Mohammad Shahbakhti, Ana Santos Rodrigues, Piotr Augustyniak, Anna Broniec-Wójcik,
Andrius Sološenko, Matin Beiramvand, and Vaidotas Marozasa},
  journal={Biomedical Signal processing and Control},
  volume={65},
  number={3},
  pages={1-8},
  year={2021},
  publisher={Elsevier}
}