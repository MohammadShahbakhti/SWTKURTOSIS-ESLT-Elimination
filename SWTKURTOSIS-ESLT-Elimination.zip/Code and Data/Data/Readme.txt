Information regarding the different databases: 

Developmet_Data, Mendeley EEG-EOG dataset, Fs=200 Hz, 95 signals
Source (https://doi.org/10.1016/j.dib.2016.06.032)   

Test_Data, CHB-MIT EEG dataset, Fs=256 Hz, 192 signals
Source (https://archive.physionet.org/cgi-bin/atm/ATM)


Real_Data, EEGLAB dataset, Fs=128 Hz, 12 signals 
Source ((http://sccn.ucsd.edu/eeglab/).


Information for data when you read them in MATLAB environment:
 

Clean_EEG: Artifact_free EEGs

ESLT_Artifact: Artificial generated ESLT artifacts 

Contaminated_EEG: EEGs contaminated with ELST artifacts

EEG_SWT: Filtered EEGs by the proposed algorithm (SWT-kurtosis)

EEG_AWICA: Filtered EEGs by the AWICA algorithm

EEG_EAWICA: Filtered EEGs by the EAWICA algorithm