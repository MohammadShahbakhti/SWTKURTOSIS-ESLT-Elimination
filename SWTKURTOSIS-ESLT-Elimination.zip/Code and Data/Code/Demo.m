%This is the demo code for the multi-channel EEG filtering of ELST artifact(n*m), 
%where n is the number of channels and m is the number of samples  

%To find the optimal value of the threshold (T) for your own dataset, you can directly contact the
%corresponding author at mohammad.shahbakhti@ktu.edu

T=0.1; %Threshold value 

for i=1:size(Contaminated_EEG,1) %Contaminated_EEG is the artifactual EEG
    
    filt_EEG(i,:)=SWTKURTOSIS_ESLT(Contaminated_EEG(i,:),T); %filt_EEG is the filtered EEG 
    
end
