
function sigDEN = SWTKURTOSIS_ESLT(SIG,T)
n=4;
e=0;


[swa,~]=swt(SIG,3,'db1');
s(3,1)=kurtosis(swa(3,:));
clear swa swd

while e<T
       [swa,~]=swt(SIG,n,'db1');

    s(n,1)=kurtosis(swa(n,:));
    e=abs(s(n,1)-s(n-1,1));
    n=n+1;
end
m=n-1;

% Decompose using SWT.
%---------------------
wDEC = swt(SIG,m,'db1');


len = length(SIG);
sorh = 'h';    

for i=1:m
wDEC(i,:) = wthresh(wDEC(i,:),'h',median(abs(wDEC(i,:)))/0.6745*sqrt(2*log(len)));
end

%-------------------------------------------
artifact = iswt(wDEC,'db1');

sigDEN = SIG-artifact;
end
